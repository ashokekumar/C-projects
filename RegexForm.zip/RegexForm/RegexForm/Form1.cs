﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;


using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Linq;

namespace RegexForm
{
    public partial class Form1 : Form
    {
        private string FileName = "";
        //        public string pattern = @"((\+(\d+|\s+|\-|\.|\‑)+)|(\+\d+)|(me\/\d+)|(phone\=\d+)|(Phone\s+\d+)|((wa|WA)\s+\d+))|((wa|WA)(\s|\:)*\d+)|(\(\d+\)(\s+\d+)+)|((\d+|\-)+)|(\d{8,})";
        //public string pattern = @"((\+(\d+|\s+|\-|\.|\‑)+)|(\+\d+)|(me\/\d+)|(phone\=\d+)|(Phone\s+\d+)|((wa|WA)(\s+\d+)+))|((wa|WA)(\s|\:)*\d+(\s+\d+)*)|(\(\d+\)(\s+\d+)+)|((\d{4,}|\-)+)|(\d{8,})";
        //public string pattern = @"((08(\d|\s|\-)+)|(62(\d|\s|\-)+)|(79(\d|\s|\-)+)";
        public string pattern = @"(62\s+\(\d\)\s+(\d|\s|\-)+)|((08|62|79)(\d|\s|\-)+)";

        public Excel._Worksheet sheet;
        public Form1()
        {
            InitializeComponent();
        }

        private void MatchData(string text, int row)
        {




            MatchCollection matchCollection = Regex.Matches(text, pattern);

            foreach (Match match in matchCollection)
            {
                string phone = match.ToString();//.Replace(" ", "").Replace("-", "").Replace(".", "").Replace("=", "").Replace("/", "").Replace("+", "");
                                                //phone = phone.Replace("me", "").Replace("phone", "").Replace("wa", "");
                                                
                string numericPhone = new String(phone.Where(Char.IsDigit).ToArray());
                if (numericPhone.Substring(0, 1) == "0") numericPhone = "62" + numericPhone.Substring(1);


                if (numericPhone.Length > 7)
                {
                    if (numericPhone.Length > 14) {
                        numericPhone = numericPhone.Substring(0, 12); }

                    sheet.Cells[row, 3] = "'" + numericPhone;
                    break;
                }

            }

        }
        private void submit_Click(object sender, EventArgs e)
        {
        }

        private void btnChoose_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = string.Empty;
                string fileExt = string.Empty;
                OpenFileDialog file = new OpenFileDialog();//open dialog to choose file
                if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK)//if there is a file choosen by the user
                {
                    filePath = file.FileName;//get the path of the file
                    fileExt = Path.GetExtension(filePath);//get the file extension
                    if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                    {
                        FileName = filePath;

                        ReadData();
                    }

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void ReadData()
        {
            //this.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;

            //Next step is to open the Excel file and get the specified worksheet
            Excel.Application application = new Excel.Application();
            Excel.Workbook wBook = application.Workbooks.Open(FileName);
            sheet = wBook.Sheets[1];

            Excel.Range range = sheet.UsedRange;

            int RowsCount = range.Count;

            progressBar1.Show();
            progressBar1.Maximum = RowsCount;


            for (int row = 1; row < RowsCount; row++)
            {
                progressBar1.Value = row;

                if (range.Cells[row, 1] != null && range.Cells[row, 1].Value2 != null)
                {
                    string data = range.Cells[row, 1].Value2.ToString();
                    MatchData(data, row);

                }
                else
                {
                    progressBar1.Value = RowsCount;

                    break;
                }
            }

            //application.Visible = false;
            //application.UserControl = false;
            wBook.Save();


            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(sheet);

            string ext = Path.GetExtension(FileName);
            FileName = Path.GetFileNameWithoutExtension(FileName);

            wBook.SaveCopyAs(FileName + "Copy" + ext);

            //close and release
            wBook.Close(true);
            Marshal.ReleaseComObject(wBook);

            //quit and release
            application.Quit();

            Marshal.ReleaseComObject(application);


            MessageBox.Show("Complete!");
            //this.Enabled = true;




            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;

        }
    }
}
